class estudiantes:personas{

    public string curso{get;set;} 
    public estudiantes(string nombre, string apellidos, string cedula, string estadocivil, string curso):base(nombre, apellidos, cedula, estadocivil){
     this.curso=curso;
     
    }
    public void Icambio(){

        Console.WriteLine("Ingrese el curso al que fue matriculado: ");
        Console.WriteLine("Nuevo curso al que fue matriculado: "+ Console.ReadLine());

    }

    public new void imprimir(){
        
        Console.WriteLine("Nombre: "+ nombre);
        Console.WriteLine("Apellidos: "+ apellidos);
        Console.WriteLine("Cédula: "+ cedula);
        Console.WriteLine("Estado civil: "+ estadocivil);
        Console.WriteLine("Curso en el que está matriculado: "+ curso);
    }


}