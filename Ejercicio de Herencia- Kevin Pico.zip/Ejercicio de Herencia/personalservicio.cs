class personalservicio:personas{

    
    public string asignado{get;set;}
    
    public personalservicio(string nombre, string apellidos, string cedula, string estadocivil, string asignado):base(nombre, apellidos, cedula, estadocivil){
     this.asignado=asignado;
    }
    
    public void Icambio(){
        

        Console.WriteLine("Ingrese la sección trasladada: ");
        Console.WriteLine("Sección nueva asignada: "+ Console.ReadLine());

    }

    public new void imprimir(){
        
        Console.WriteLine("Nombre: "+ nombre);
        Console.WriteLine("Apellidos: "+ apellidos);
        Console.WriteLine("Cédula: "+ cedula);
        Console.WriteLine("Estado civil: "+ estadocivil);
        Console.WriteLine("Sección a la que está asignado: "+ asignado);
    }



}