class empleados :personas{

    public string añoincorporacion{get;set;}
    public string numeroD{get; set;}
    public empleados(string nombre, string apellidos, string cedula, string estadocivil, string añoincorporacion, string numeroD):base(nombre, apellidos,cedula, estadocivil){
     this.añoincorporacion=añoincorporacion;
     this.numeroD=numeroD;
    }
    public void Icambiode(){
       

        Console.WriteLine("Ingrese el despacho al que fue reasignado: ");
        Console.WriteLine("Nuevo despacho: "+ Console.ReadLine());

    }

    public new void imprimir(){
        
        Console.WriteLine("Nombre: "+ nombre);
        Console.WriteLine("Apellidos: "+ apellidos);
        Console.WriteLine("Cédula: "+ cedula);
        Console.WriteLine("Estado civil: "+ estadocivil);
        Console.WriteLine("Año de incorporación: "+ añoincorporacion);
        Console.WriteLine("Número de despacho: "+ numeroD);
    }

    internal void Icambio()
    {
        throw new NotImplementedException();
    }
}