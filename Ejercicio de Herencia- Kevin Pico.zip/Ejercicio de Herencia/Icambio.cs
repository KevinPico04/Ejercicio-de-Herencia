interface Icambio{
    public void cambio();
}