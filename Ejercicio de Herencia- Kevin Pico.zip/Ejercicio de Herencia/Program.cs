﻿internal class Program
{
    private static void Main(string[] args)
    {        
        empleados EM= new empleados("Pedro","Perez ","13208924690","Soltero","2008","3");
        EM.imprimir();
        EM.cambioestadocivil();
        EM.Icambio();

        estudiantes E= new estudiantes("David","Rosado","1311647589","Casado","1 B");
        E.imprimir();
        E.cambioestadocivil();
        E.Icambio();
        
        profesores P= new profesores("Pepe","Rodriguez","1358884025","Soltero","Dibujo");
        P.imprimir();
        P.cambioestadocivil();
        P.Icambio();
        
        personalservicio PS= new personalservicio("Gaby","Suarez","1316398588","Soltera","Laboratorio");
        PS.imprimir(); 
        PS.cambioestadocivil();
        PS.Icambio();
    }
}