class personas{
    public string nombre{get;set;}
    public string apellidos{get;set;}
    public string cedula{get;set;}
    public string estadocivil{get;set;}
    public personas(string nombre, string apellidos, string cedula, string estadocivil){
        this.nombre=nombre;
        this.cedula=cedula;
        this.apellidos=apellidos;
        this.estadocivil=estadocivil;
    }
    public void cambioestadocivil(){
        Console.WriteLine("Ingrese su nuevo estado civil: ");
        Console.WriteLine("Su nuevo estado civil es: "+Console.ReadLine());
    }
    public void imprimir(){
        Console.WriteLine("Nombre: "+nombre);
        Console.WriteLine("Apellidos: "+apellidos);
        Console.WriteLine("Su numero de cedula es: "+cedula);
        Console.WriteLine("Estado Civil: "+estadocivil);
    }
}